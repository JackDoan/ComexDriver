// nothrow -- define nothrow object
#include <new>
#include <yvals.h>
_STD_BEGIN

const nothrow_t nothrow = nothrow_t();	// define nothrow
_STD_END

/*
 * Copyright (c) 1992-2004 by P.J. Plauger.  ALL RIGHTS RESERVED.
 * Consult your license regarding permissions and restrictions.
V4.02:1476 */
